package com.example.simpleapi.Services;

import com.example.simpleapi.Entity.Student;
import com.example.simpleapi.Repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class StudentService {
    @Autowired
    StudentRepository studentRepository;

    public ResponseEntity<String> addStudent(Student student) {
        try {
            studentRepository.save(student);
            return new ResponseEntity<>("Ok, 1 Row Effected", HttpStatus.CREATED);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>("Failed", HttpStatus.NOT_ACCEPTABLE);
    }

    public ResponseEntity<List<Student>>getStudent() {
        try{
            return new ResponseEntity<>(studentRepository.findAll(), HttpStatus.OK);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return new ResponseEntity<>(new ArrayList<>(), HttpStatus.BAD_REQUEST);
    }

    public ResponseEntity<String> updateStudent(Student student) {
        try{
            studentRepository.save(student);
            return new ResponseEntity<>("OK, 1 row Effected", HttpStatus.OK);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return new ResponseEntity<>("Failed", HttpStatus.NOT_ACCEPTABLE);
    }

    public ResponseEntity<String> deleteStudent(int rollNo) {
        try{
            studentRepository.deleteById(rollNo);
            return new ResponseEntity<>("OK, 1 Row Effected", HttpStatus.OK);
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return new ResponseEntity<>("Failed", HttpStatus.NOT_ACCEPTABLE);
    }
}